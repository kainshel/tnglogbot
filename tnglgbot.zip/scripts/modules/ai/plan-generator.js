// plan-generator.js
